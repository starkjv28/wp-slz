<?php

require_once( TDC_PATH . '/legacy/common/wp_booster/comments.php');
