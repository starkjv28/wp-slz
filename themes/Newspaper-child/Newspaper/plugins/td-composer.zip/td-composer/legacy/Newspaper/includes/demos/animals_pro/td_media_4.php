<?php

//post photos
td_demo_media::add_image_to_media_gallery('td_pic_p1',                              "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/p1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p2',                              "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/p2.jpg");

//logo symbol
td_demo_media::add_image_to_media_gallery('td_logo_symbol',                         'http://demo_content.tagdiv.com/Newspaper_6/animals_pro/logo-symbol.png');

//404 image
td_demo_media::add_image_to_media_gallery('td_pic_404',                             "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/404.png");